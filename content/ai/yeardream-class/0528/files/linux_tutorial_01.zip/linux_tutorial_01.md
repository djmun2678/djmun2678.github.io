# 1. 현재 위치 확인 

## 현재 디렉터리 확인
- 현재 내가 어느 위치에 있는지 절대 경로로 출력

```bash
$ pwd
/c/Users/중진공57/Desktop/test
```

## 바탕화면으로 이동 
- `cd` 명령어로 원하는 디렉터리로 이동

```bash
$ cd ~/Desktop
```

## 현재 위치의 파일 폴더 목록 보기 
- 현재 디렉터리 안의 파일과 폴더를 나열

```bash
$ ls
```

- 숨김 파일 포함, 상세 정보까지 보기
```bash
$ ls -al
```

# 2. 폴더(디렉터리) 만들기 및 이동
## test 폴더 안에서 새로운 폴더 만들기
- `mkdir`로 새로운 폴더 생성
```bash
mkdir linux_practice
```

- 중첩 폴더를 한번에 만들기 (`-p` 옵션)
```bash 
mkdir -p linux_practice/src/utils
```

## 만든 폴더로 이동

```bash
cd linux_practice
```

## 상위 폴더로 이동하기
```bash
cd ..
```

---

# 3. 파일 만들기 및 내용 확인
## 빈 파일 만들기 (touch)
- `touch`로 빈 파일 생성